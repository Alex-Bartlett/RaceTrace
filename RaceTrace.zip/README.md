# RaceTrace

A Formula One lap time visualisation tool
